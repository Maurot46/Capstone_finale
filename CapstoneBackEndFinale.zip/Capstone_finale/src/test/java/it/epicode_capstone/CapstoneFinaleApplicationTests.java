package it.epicode_capstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneFinaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
