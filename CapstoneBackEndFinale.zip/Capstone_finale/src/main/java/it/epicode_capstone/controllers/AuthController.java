package it.epicode_capstone.controllers;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.epicode_capstone.exceptions.UserExistsResponse;
import it.epicode_capstone.models.ERole;
import it.epicode_capstone.models.Restaurateur;
import it.epicode_capstone.models.Role;
import it.epicode_capstone.models.User;
import it.epicode_capstone.payload.request.LoginRequest;
import it.epicode_capstone.payload.request.SignupRequest;
import it.epicode_capstone.payload.request.SignupRequestRestaurateur;
import it.epicode_capstone.payload.response.JwtResponse;
import it.epicode_capstone.payload.response.MessageResponse;
import it.epicode_capstone.repositories.RestaurateurRepository;
import it.epicode_capstone.repositories.RoleRepository;
import it.epicode_capstone.repositories.UserRepository;
import it.epicode_capstone.security.jwt.JwtTokenBlacklistService;
import it.epicode_capstone.security.jwt.JwtUtils;
import it.epicode_capstone.security.services.UserDetailsImpl;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController {
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	UserRepository userRepository;
	@Autowired
	RestaurateurRepository restaurateurRepository;
	@Autowired
	RoleRepository roleRepository;
	@Autowired
	PasswordEncoder encoder;
	@Autowired
	JwtUtils jwtUtils;
	@Autowired
    private JwtTokenBlacklistService jwtTokenBlacklistService;
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtUtils.generateJwtToken(authentication);
		
		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();		
		List<String> roles = userDetails.getAuthorities().stream()
				.map(item -> item.getAuthority())
				.collect(Collectors.toList());

		return ResponseEntity.ok(new JwtResponse(jwt, 
												 userDetails.getId(), 
												 userDetails.getUsername(), 
												 userDetails.getEmail(), 
												 roles));
	}

	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Errore: Username già utilizzato!"));
		}

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Errore: Email già utilizzata!"));
		}
		signUpRequest.setActive(true);
		// Create new user's account
		User user = new User(signUpRequest.getUsername(), 
							 signUpRequest.getEmail(),
							 encoder.encode(signUpRequest.getPassword()),
							 signUpRequest.getName(),
							 signUpRequest.getSurname(),
							 signUpRequest.getActive(),
							 signUpRequest.getAddress());

		Set<String> strRoles = signUpRequest.getRole();
		Set<Role> roles = new HashSet<>();

		if (strRoles == null) {
			Role userRole = roleRepository.findByName(ERole.ROLE_USER)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
			roles.add(userRole);
		} else {
			strRoles.forEach(role -> {
				switch (role) {
				case "admin":
					Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(adminRole);

					break;
				case "ristoratore":
					Role modRole = roleRepository.findByName(ERole.ROLE_RISTORATORE)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(modRole);

					break;
				default:
					Role userRole = roleRepository.findByName(ERole.ROLE_USER)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(userRole);
				}
			});
		}

		user.setRoles(roles);
		userRepository.save(user);

		return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
	}
	@PostMapping("/signout")
    public ResponseEntity<?> signOut(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return ResponseEntity.ok(new MessageResponse("Successfully signed out"));
    }
	//Check username and email availability for USER
	@GetMapping("/users/existsByUsername")
    public ResponseEntity<?> existsByUsername(@RequestParam("username") String username) {
        boolean exists = userRepository.existsByUsername(username);
        return ResponseEntity.ok(new UserExistsResponse(exists));
    }
	@GetMapping("/users/existsByEmail")
    public ResponseEntity<?> existsByEmail(@RequestParam("email") String email) {
        boolean exists = userRepository.existsByEmail(email);
        return ResponseEntity.ok(new UserExistsResponse(exists));
    }
	//Check username and email availability for RISTORATORE
	
	//Register Restaurateur
	@PostMapping("/signupRestaurateur")
	public ResponseEntity<?> registerRestaurateur(@Valid @RequestBody SignupRequestRestaurateur signUpRequest) {
		if (restaurateurRepository.existsByUsername(signUpRequest.getUsername())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Errore: Username già utilizzato!"));
		}

		if (restaurateurRepository.existsByEmail(signUpRequest.getEmail())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Errore: Email già utilizzata!"));
		}
		signUpRequest.setActive(true);
		// Create new user's account
		Restaurateur restaurateur = new Restaurateur(signUpRequest.getUsername(), 
                signUpRequest.getEmail(),
                encoder.encode(signUpRequest.getPassword()),
                signUpRequest.getName(),
                signUpRequest.getSurname(),
                true,
                signUpRequest.getAddress(),
                signUpRequest.getNumeroPartitaIva(),
                signUpRequest.getPhoneNumber(),
                signUpRequest.getIndirizzoRistorante());

		Set<String> strRoles = signUpRequest.getRole();
		Set<Role> roles = new HashSet<>();

		if (strRoles == null) {
			Role ristoratoreRole = roleRepository.findByName(ERole.ROLE_RISTORATORE)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
			roles.add(ristoratoreRole);
		} else {
			strRoles.forEach(role -> {
				switch (role) {
				case "admin":
					Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(adminRole);

					break;
				case "ristoratore":
					Role ristoratoreRole = roleRepository.findByName(ERole.ROLE_RISTORATORE)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(ristoratoreRole);

					break;
				default:
					Role userRole = roleRepository.findByName(ERole.ROLE_USER)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(userRole);
				}
			});
		}

		restaurateur.setRoles(roles);
		restaurateurRepository.save(restaurateur);

		return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
	}

}
