package it.epicode_capstone.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.epicode_capstone.exceptions.ResourceNotFoundException;
import it.epicode_capstone.models.Menu;
import it.epicode_capstone.models.MenuItem;
import it.epicode_capstone.models.Restaurateur;
import it.epicode_capstone.repositories.MenuItemsRepository;
import it.epicode_capstone.security.services.MenuItemsService;
import it.epicode_capstone.security.services.MenuService;
import it.epicode_capstone.security.services.RestaurateurService;

@RestController
@RequestMapping("/api/menus")
@CrossOrigin(origins = "http://localhost:4200")
public class MenuController {
	@Autowired
	MenuService menuService;
	@Autowired
	MenuItemsService menuItemsService;
	@Autowired
	RestaurateurService restaurateurService;
	@Autowired
	MenuItemsRepository menuItemsRepository;
	@PostMapping("/add")
	public ResponseEntity<Menu> addMenu(@RequestBody Menu menu) {
	    Restaurateur restaurateur = restaurateurService.getRestaurateurById(menu.getRestaurateur().getId());
	    menu.setRestaurateur(restaurateur);
	    Menu savedMenu = menuService.createMenu(menu);
	    return ResponseEntity.ok(savedMenu);
	}
	@PutMapping("/update/{id}")
    public ResponseEntity<Menu> updateMenu(@PathVariable Long id, @RequestBody Menu updatedMenu) {
        Menu menu = menuService.updateMenu(id, updatedMenu);
        return ResponseEntity.ok(menu);
    }
	@GetMapping("/restaurateur/{id}")
	public ResponseEntity<List<Menu>> getMenuByRestaurateurId(@PathVariable Long id) {
	    List<Menu> menus = menuService.getMenuByRestaurateurId(id);
	    if (menus.isEmpty()) {
	        return ResponseEntity.notFound().build();
	    } else {
	        // Access the menus property of each Restaurateur entity to ensure that all associated Menu entities are loaded
	        menus.forEach(menu -> menu.getRestaurateur().getMenus().size());
	        return ResponseEntity.ok(menus);
	    }
	}
	@PostMapping("/{id}/items")
	public ResponseEntity<MenuItem> addMenuItemToMenu(@PathVariable Long id, @RequestBody MenuItem menuItem) {
	    menuItemsService.addMenuItemToMenu(id, menuItem);
	    MenuItem addedMenuItem = menuItemsRepository.findById(menuItem.getId())
	            .orElseThrow(() -> new ResourceNotFoundException("Menu item not found with id: " + menuItem.getId()));
	    return ResponseEntity.status(HttpStatus.CREATED).body(addedMenuItem);
	}
	@DeleteMapping("/delete/{id}")
	  public void deleteMenu(@PathVariable Long id) {
		menuService.deleteMenu(id);
	}
	@GetMapping("/{menuId}/menu-items")
	public List<MenuItem> getMenuItemsByMenuId(@PathVariable Long menuId) {
	    Menu menu = menuService.getMenuById(menuId);
	    return menu.getMenuItems();
	}
	@PutMapping("/{itemId}")
    public MenuItem updateMenuItem(@PathVariable Long itemId, @RequestBody MenuItem menuItem) {
        return menuItemsService.updateMenuItem(itemId, menuItem);
    }
}
