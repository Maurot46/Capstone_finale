package it.epicode_capstone.controllers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.epicode_capstone.exceptions.MenuItemNotFoundException;
import it.epicode_capstone.exceptions.ResourceNotFoundException;
import it.epicode_capstone.exceptions.RestaurateurNotFoundException;
import it.epicode_capstone.exceptions.UserNotFoundException;
import it.epicode_capstone.models.MenuItem;
import it.epicode_capstone.models.Order;
import it.epicode_capstone.models.OrderItem;
import it.epicode_capstone.models.OrderStatus;
import it.epicode_capstone.models.Restaurateur;
import it.epicode_capstone.models.User;
import it.epicode_capstone.payload.request.OrderItemRequest;
import it.epicode_capstone.payload.request.OrderRequest;
import it.epicode_capstone.repositories.MenuItemRepository;
import it.epicode_capstone.repositories.OrderRepository;
import it.epicode_capstone.repositories.RestaurateurRepository;
import it.epicode_capstone.repositories.UserRepository;
import it.epicode_capstone.security.services.OrderService;
import org.springframework.data.domain.Pageable;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
	private final OrderService orderService;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RestaurateurRepository restaurateurRepository;
	@Autowired
	private MenuItemRepository menuItemRepository;
	@Autowired
	private OrderRepository orderRepository;

	public OrderController(OrderService orderService) {
		this.orderService = orderService;
	}

	@PostMapping("/create")
	public ResponseEntity<?> createOrder(@Valid @RequestBody OrderRequest orderRequest) {
		User user = userRepository.findById(orderRequest.getUserId())
				.orElseThrow(() -> new UserNotFoundException("User not found with id " + orderRequest.getUserId()));

		Restaurateur restaurateur = restaurateurRepository.findById(orderRequest.getRestaurateurId())
				.orElseThrow(() -> new RestaurateurNotFoundException(
						"Restaurateur not found with id " + orderRequest.getRestaurateurId()));

		Order order = new Order();
		order.setUser(user);
		order.setRestaurateur(restaurateur);
		order.setCreationDateTime(LocalDateTime.now());
		order.setStatus(OrderStatus.PENDING);

		List<OrderItem> orderItems = new ArrayList<>();

		for (OrderItemRequest orderItemRequest : orderRequest.getOrderItems()) {
			MenuItem menuItem = menuItemRepository.findById(orderItemRequest.getMenuItemId())
					.orElseThrow(() -> new MenuItemNotFoundException(
							"Menu item not found with id " + orderItemRequest.getMenuItemId()));

			OrderItem orderItem = new OrderItem();
			orderItem.setMenuItem(menuItem);
			orderItem.setQuantity(orderItemRequest.getQuantity());
			orderItem.setTotalPrice(menuItem.getPrice() * orderItemRequest.getQuantity());
			orderItem.setOrder(order);

			orderItems.add(orderItem);
		}

		order.setOrderItems(orderItems);
		order.calculateTotalPrice();

		Order savedOrder = orderRepository.save(order);
		return ResponseEntity.ok(savedOrder);
	}

	@GetMapping("/restaurateur/{restaurateurId}")
	public Page<Order> getAllOrdersByRestaurateurId(@PathVariable Long restaurateurId, Pageable pageable) {
	    return orderRepository.findByRestaurateurId(restaurateurId, pageable);
	}
	@PutMapping("/{orderId}/approve")
	public ResponseEntity<?> approveOrder(@PathVariable Long orderId) {
	    Order order = orderRepository.findById(orderId)
	            .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
	    
	    if (order.getStatus() == OrderStatus.PENDING) {
	        order.setStatus(OrderStatus.PROCESSING);
	        order.setCreationDateTime(LocalDateTime.now());
	        orderRepository.save(order);
	        return ResponseEntity.ok("");
	    } else {
	        return ResponseEntity.badRequest().body("Order status is not PENDING, cannot be approved");
	    }
	}
	@PutMapping("/{orderId}/complete")
	public ResponseEntity<?> completeOrder(@PathVariable Long orderId) {
	    Order order = orderRepository.findById(orderId)
	            .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
	    
	    if (order.getStatus() == OrderStatus.PROCESSING) {
	        order.setStatus(OrderStatus.COMPLETED);
	        order.setCreationDateTime(LocalDateTime.now());
	        orderRepository.save(order);
	        return ResponseEntity.ok("");
	    } else {
	        return ResponseEntity.badRequest().body("Order status is not Processing, cannot be completed");
	    }
	}
	@PutMapping("/{orderId}/cancelled")
	public ResponseEntity<?> cancelledOrder(@PathVariable Long orderId) {
	    Order order = orderRepository.findById(orderId)
	            .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
	    
	    if (order.getStatus() == OrderStatus.PENDING) {
	        order.setStatus(OrderStatus.CANCELLED);
	        order.setCreationDateTime(LocalDateTime.now());
	        orderRepository.save(order);
	        return ResponseEntity.ok("");
	    } else {
	        return ResponseEntity.badRequest().body("Order status is not Processing, cannot be completed");
	    }
	}


}
