package it.epicode_capstone.security.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode_capstone.exceptions.MenuItemNotFoundException;
import it.epicode_capstone.exceptions.ResourceNotFoundException;
import it.epicode_capstone.exceptions.RestaurateurNotFoundException;
import it.epicode_capstone.exceptions.UserNotFoundException;
import it.epicode_capstone.models.MenuItem;
import it.epicode_capstone.models.Order;
import it.epicode_capstone.models.OrderItem;
import it.epicode_capstone.models.OrderItemDto;
import it.epicode_capstone.models.OrderStatus;
import it.epicode_capstone.models.Restaurateur;
import it.epicode_capstone.models.User;
import it.epicode_capstone.payload.request.OrderItemRequest;
import it.epicode_capstone.payload.request.OrderRequest;
import it.epicode_capstone.repositories.MenuItemsRepository;
import it.epicode_capstone.repositories.OrderRepository;
import it.epicode_capstone.repositories.RestaurateurRepository;
import it.epicode_capstone.repositories.UserRepository;

@Service
public class OrderService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RestaurateurRepository restaurateurRepository;

	@Autowired
	private MenuItemsRepository menuItemRepository;

	@Autowired
	private OrderRepository orderRepository;

	public Order createOrder(OrderRequest orderRequest) {
		User user = userRepository.findById(orderRequest.getUserId())
				.orElseThrow(() -> new UserNotFoundException("User not found with id " + orderRequest.getUserId()));

		Restaurateur restaurateur = restaurateurRepository.findById(orderRequest.getRestaurateurId())
				.orElseThrow(() -> new RestaurateurNotFoundException(
						"Restaurateur not found with id " + orderRequest.getRestaurateurId()));

		Order order = new Order();
		order.setUser(user);
		order.setRestaurateur(restaurateur);
		order.setCreationDateTime(LocalDateTime.now());
		order.setStatus(OrderStatus.PENDING);

		List<OrderItem> orderItems = new ArrayList<>();

		for (OrderItemRequest orderItemRequest : orderRequest.getOrderItems()) {
			MenuItem menuItem = menuItemRepository.findById(orderItemRequest.getMenuItemId())
					.orElseThrow(() -> new MenuItemNotFoundException(
							"Menu item not found with id " + orderItemRequest.getMenuItemId()));

			OrderItem orderItem = new OrderItem();
			orderItem.setMenuItem(menuItem);
			orderItem.setQuantity(orderItemRequest.getQuantity());
			orderItem.setTotalPrice(menuItem.getPrice() * orderItemRequest.getQuantity());

			orderItems.add(orderItem);
		}

		order.setOrderItems(orderItems);
		order.calculateTotalPrice();

		return orderRepository.save(order);
	}
}
