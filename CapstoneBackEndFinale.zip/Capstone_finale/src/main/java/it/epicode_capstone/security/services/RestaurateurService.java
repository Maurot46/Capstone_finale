package it.epicode_capstone.security.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode_capstone.exceptions.ResourceNotFoundException;
import it.epicode_capstone.models.Restaurateur;
import it.epicode_capstone.repositories.RestaurateurRepository;

@Service
public class RestaurateurService {
	@Autowired
    private RestaurateurRepository restaurateurRepository;

    public Restaurateur getRestaurateurById(Long id) {
        Optional<Restaurateur> restaurateur = restaurateurRepository.findById(id);
        if (restaurateur.isPresent()) {
            return restaurateur.get();
        } else {
            // throw an exception if the restaurateur is not found
            throw new ResourceNotFoundException("Restaurateur", "id", id);
        }
    }
    public List<Restaurateur> getAllRestaurateurs() {
        return restaurateurRepository.findAll();
    }
}
