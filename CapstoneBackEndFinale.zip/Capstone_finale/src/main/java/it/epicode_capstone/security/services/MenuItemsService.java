package it.epicode_capstone.security.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode_capstone.exceptions.ResourceNotFoundException;
import it.epicode_capstone.models.Menu;
import it.epicode_capstone.models.MenuItem;
import it.epicode_capstone.repositories.MenuItemsRepository;
import it.epicode_capstone.repositories.MenuRepository;

@Service
public class MenuItemsService {
	@Autowired
	MenuItemsRepository menuItemsRepository;
	@Autowired
	MenuRepository menuRepository;

	public void addMenuItemToMenu(Long menuId, MenuItem menuItem) {
		Optional<Menu> optionalMenu = menuRepository.findById(menuId);
		if (optionalMenu.isPresent()) {
			Menu menu = optionalMenu.get();
			menuItem.setMenu(menu);
			menuItemsRepository.save(menuItem);
		} else {
			throw new ResourceNotFoundException("Menu not found with id: " + menuId);
		}
	}

	public MenuItem updateMenuItem(Long id, MenuItem menuItem) {
		MenuItem existingMenuItem = menuItemsRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Menu item not found with id: " + id));
		existingMenuItem.setName(menuItem.getName());
		existingMenuItem.setIngredients(menuItem.getIngredients());
		existingMenuItem.setPrice(menuItem.getPrice());
		return menuItemsRepository.save(existingMenuItem);
	}

}
