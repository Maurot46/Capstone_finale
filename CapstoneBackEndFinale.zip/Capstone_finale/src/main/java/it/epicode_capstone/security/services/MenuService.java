package it.epicode_capstone.security.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode_capstone.exceptions.ResourceNotFoundException;
import it.epicode_capstone.models.Menu;
import it.epicode_capstone.models.Restaurateur;
import it.epicode_capstone.repositories.MenuDTO;
import it.epicode_capstone.repositories.MenuRepository;

@Service
public class MenuService {
	@Autowired
	private MenuRepository menuRepository;

	// Create
    public Menu createMenu(Menu menu) {
        return menuRepository.save(menu);
    }
 // Read
    public Menu getMenuById(Long id) {
        return menuRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Menu not found with id: " + id));
    }

    public List<Menu> getAllMenus() {
        return menuRepository.findAll();
    }

    // Update
    public Menu updateMenu(Long id, Menu updatedMenu) {
        Menu existingMenu = getMenuById(id);
        existingMenu.setName(updatedMenu.getName());
        existingMenu.setTipologia(updatedMenu.getTipologia());
        existingMenu.setRestaurateur(updatedMenu.getRestaurateur());
        existingMenu.setMenuItems(updatedMenu.getMenuItems());
        return menuRepository.save(existingMenu);
    }

    // Delete
    public void deleteMenu(Long id) {
        menuRepository.deleteById(id);
    }
    public List<Menu> getMenuByRestaurateurId(Long restaurateurId) {
        return menuRepository.findByRestaurateurId(restaurateurId);
    }
}
