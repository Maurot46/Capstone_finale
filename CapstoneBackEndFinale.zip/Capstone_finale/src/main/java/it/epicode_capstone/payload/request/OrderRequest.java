package it.epicode_capstone.payload.request;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import it.epicode_capstone.models.OrderItemDto;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class OrderRequest {
	 private Long userId;
	  private Long restaurateurId;
	  private List<OrderItemRequest> orderItems;
}
