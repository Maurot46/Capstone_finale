package it.epicode_capstone.payload.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderItemRequest {
	private Long menuItemId;
	private Integer quantity;
}
