package it.epicode_capstone.exceptions;

public class MenuItemNotFoundException extends RuntimeException{
	public MenuItemNotFoundException(String message) {
        super(message);
    }
}
