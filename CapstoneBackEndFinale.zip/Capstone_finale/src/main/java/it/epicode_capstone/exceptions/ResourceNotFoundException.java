package it.epicode_capstone.exceptions;

public class ResourceNotFoundException extends RuntimeException{
	public ResourceNotFoundException(String resourceName, String fieldName, Long fieldValue) {
        super(String.format("%s not found with %s : '%s'", resourceName, fieldName, fieldValue));
    }
	public ResourceNotFoundException(String resourceName, String fieldName, String fieldValue) {
        super(String.format("%s not found with %s : '%s'", resourceName, fieldName, fieldValue));
    }
	public ResourceNotFoundException(String string) {
		super(String.format("resource not found with %s ", string));
	}
}
