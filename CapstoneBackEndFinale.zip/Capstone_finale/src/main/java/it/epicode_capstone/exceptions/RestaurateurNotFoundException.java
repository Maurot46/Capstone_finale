package it.epicode_capstone.exceptions;

public class RestaurateurNotFoundException extends RuntimeException{
	public RestaurateurNotFoundException(String message) {
        super(message);
    }
}
