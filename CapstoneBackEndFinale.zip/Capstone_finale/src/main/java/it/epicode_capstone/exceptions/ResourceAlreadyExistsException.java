package it.epicode_capstone.exceptions;

public class ResourceAlreadyExistsException extends RuntimeException{
	public ResourceAlreadyExistsException(String resourceName, String fieldValue) {
        super(String.format("%s with %s '%s' already exists", resourceName, fieldValue));
    }
}
