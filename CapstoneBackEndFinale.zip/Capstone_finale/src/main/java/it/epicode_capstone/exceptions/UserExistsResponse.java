package it.epicode_capstone.exceptions;

public class UserExistsResponse {
	private boolean exists;

	public UserExistsResponse(boolean exists) {
		this.exists = exists;
	}

	public boolean isExists() {
		return exists;
	}

	public void setExists(boolean exists) {
		this.exists = exists;
	}
}
