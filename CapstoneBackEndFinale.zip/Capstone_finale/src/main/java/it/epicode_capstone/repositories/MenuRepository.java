package it.epicode_capstone.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.epicode_capstone.models.Menu;
import it.epicode_capstone.models.Restaurateur;

@Repository
public interface MenuRepository extends JpaRepository<Menu, Long>{
	List<Menu> findByRestaurateur(Restaurateur restaurateur);
	List<Menu> findByRestaurateurId(Long id);
}
