package it.epicode_capstone.repositories;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.epicode_capstone.models.Order;
@Repository
public interface OrderRepository extends JpaRepository<Order, Long>{
	Page<Order> findByRestaurateurId(Long restaurateurId, Pageable pageable);

}
