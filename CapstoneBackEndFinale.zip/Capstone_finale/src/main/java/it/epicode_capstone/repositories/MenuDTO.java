package it.epicode_capstone.repositories;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MenuDTO {
	private Long id;
    private String name;
    private String tipologia;
    private Long restaurateurId;

    public MenuDTO(Long id, String name, String tipologia, Long restaurateurId) {
        this.id = id;
        this.name = name;
        this.tipologia = tipologia;
        this.restaurateurId = restaurateurId;
    }

    public MenuDTO() {
    }

}
