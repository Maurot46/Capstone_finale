package it.epicode_capstone.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.epicode_capstone.models.Restaurateur;

@Repository
public interface RestaurateurRepository extends JpaRepository<Restaurateur, Long>{
	Optional<Restaurateur> findByUsername(String username);
	
	Optional<Restaurateur> findByEmail(String email);
	
	Boolean existsByUsername(String username);

	Boolean existsByEmail(String email);
	
	List<Restaurateur> findAll();
}
