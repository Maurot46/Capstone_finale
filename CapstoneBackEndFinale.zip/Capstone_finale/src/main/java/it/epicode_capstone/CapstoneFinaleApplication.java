package it.epicode_capstone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import it.epicode_capstone.models.ERole;
import it.epicode_capstone.models.Role;
import it.epicode_capstone.repositories.RoleRepository;

@SpringBootApplication
public class CapstoneFinaleApplication implements CommandLineRunner{
	@Autowired
	RoleRepository roleRepo;
	public static void main(String[] args) {
		SpringApplication.run(CapstoneFinaleApplication.class, args);
		
	}

	@Override
	public void run(String... args) throws Exception {
	
			
//			Role admiRole = new Role();
//			admiRole.setName(ERole.ROLE_ADMIN);
//			roleRepo.save(admiRole);
//			Role userRole = new Role();
//			userRole.setName(ERole.ROLE_USER);
//			roleRepo.save(userRole);
//			Role ristoratoreRole = new Role();
//			ristoratoreRole.setName(ERole.ROLE_RISTORATORE);
//			roleRepo.save(ristoratoreRole);
		
	}
	

}
