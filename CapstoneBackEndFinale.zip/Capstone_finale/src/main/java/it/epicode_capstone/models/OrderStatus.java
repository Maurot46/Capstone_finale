package it.epicode_capstone.models;

public enum OrderStatus {
	PENDING,
    PROCESSING,
    COMPLETED,
    CANCELLED
}
