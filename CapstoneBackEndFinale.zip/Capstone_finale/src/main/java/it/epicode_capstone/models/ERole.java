package it.epicode_capstone.models;

public enum ERole {
	ROLE_USER,
	ROLE_RISTORATORE,
	ROLE_ADMIN
}
