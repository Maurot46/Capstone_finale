package it.epicode_capstone.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "restaurateurs")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Restaurateur extends User{
	@NotBlank
    @Size(max = 20)
    private String numeroPartitaIva;

    @NotBlank
    @Size(max = 20)
    private String phoneNumber;

    @NotBlank
    @Size(max = 100)
    private String indirizzoRistorante;

    @OneToMany(mappedBy = "restaurateur", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("restaurateur-menus")
    private List<Menu> menus = new ArrayList<>();

    public Restaurateur(String username, String email, String password, String name, String surname,
                        boolean active, String address, String numeroPartitaIva, String phoneNumber, String indirizzoRistorante) {
        super(username, email, password, name, surname, active, address);
        this.numeroPartitaIva = numeroPartitaIva;
        this.phoneNumber = phoneNumber;
        this.indirizzoRistorante = indirizzoRistorante;
    }

}
